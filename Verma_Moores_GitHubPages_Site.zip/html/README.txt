Static HTML version of the Moores impact site. Open index.html in a browser.
